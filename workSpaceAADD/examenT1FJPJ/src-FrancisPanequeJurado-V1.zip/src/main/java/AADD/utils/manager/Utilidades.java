package AADD.utils.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Utilidades {
	
	public static void crearTablaProductosNoVenta() {
        Connection connection = null;
        PreparedStatement createTableStatement = null;

        try {
            // Establecer conexión a la base de datos
            connection = AADD.utils.conexion.Conexion.conexion();

            // Crear la tabla ProductosNoVenta con la misma estructura que Products
            String createTableQuery = "CREATE TABLE IF NOT EXISTS ProductosNoVenta AS SELECT * FROM Products WHERE Discontinued = 1";
            createTableStatement = connection.prepareStatement(createTableQuery);
            createTableStatement.executeUpdate();

            System.out.println("La tabla ProductosNoVenta ha sido creada con éxito y ha sido poblada con los productos discontinuados.");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar conexiones y liberar recursos
            try {
                if (createTableStatement != null) createTableStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
