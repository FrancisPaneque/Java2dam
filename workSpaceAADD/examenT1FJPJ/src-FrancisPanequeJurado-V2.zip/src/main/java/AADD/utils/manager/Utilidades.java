package AADD.utils.manager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Utilidades {
	
	/**
	 * Metodo que crea la tabla ProductosNoVenta en la base de datos northwind como la tabla products
	 */
	public static void crearTablaProductosNoVenta() {
        Connection connection = null;
        PreparedStatement createTableStatement = null;

        try {
            // Establecer conexión a la base de datos
            connection = AADD.utils.conexion.Conexion.conexion();

            // Crear la tabla ProductosNoVenta con la misma estructura que Products
            String createTableQuery = "CREATE TABLE IF NOT EXISTS ProductosNoVenta AS SELECT * FROM Products WHERE Discontinued = 1";
            createTableStatement = connection.prepareStatement(createTableQuery);
            createTableStatement.executeUpdate();

            System.out.println("La tabla ProductosNoVenta ha sido creada con éxito y ha sido poblada con los productos discontinuados de la tabla products.");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cierra conexiones
            try {
                if (createTableStatement != null) createTableStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
	public static void cargarProductos(String archivoCSV) {
        Connection connection = null;
        BufferedReader bufferedReader = null;
        List<Products> productsList = new ArrayList<>();

        try {
            // Establecer conexión a la base de datos
            connection = AADD.utils.conexion.Conexion.conexion();
            connection.setAutoCommit(false); // Iniciar la transacción

            // Leer el archivo CSV
            bufferedReader = new BufferedReader(new FileReader(archivoCSV));
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                // Separar la línea en campos usando la coma como delimitador
                String[] values = line.split(",");

                // Crear objeto Products y agregarlo a la lista
                Products product = new Products();
                product.setProductName(values[0].trim());
                product.setSupplierId(Integer.parseInt(values[1].trim()));
                product.setCategoryId(Integer.parseInt(values[2].trim()));
                product.setQuantityPerUnit(values[3].trim());
                product.setUnitPrice(new BigDecimal(values[4].trim()));
                product.setUnitsInStock(Short.parseShort(values[5].trim()));
                product.setUnitsOnOrder(Short.parseShort(values[6].trim()));
                product.setReorderLevel(Short.parseShort(values[7].trim()));
                product.setDiscontinued(Integer.parseInt(values[8].trim()) == 1);

                productsList.add(product);
            }

        } catch (IOException | SQLException e) {
            e.printStackTrace();
            try {
                // Revertir la transacción en caso de error
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            // Cerrar conexiones y liberar recursos
            try {
                if (bufferedReader != null) bufferedReader.close();
                if (connection != null) connection.close();
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
