package AADD.main;

import java.io.IOException;

public class App {
	private static final String RUTA_FICHERO = "Ficheros/prueba.txt";
    public static void main( String[] args ) {
    	
    	
    }
}
