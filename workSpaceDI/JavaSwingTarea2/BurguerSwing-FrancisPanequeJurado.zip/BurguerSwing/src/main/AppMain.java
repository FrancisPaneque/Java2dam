package main;

import front.*;

public class AppMain {
	
	public static void main(String[] args) {
		Login pantalla = new Login();
		pantalla.setLocationRelativeTo(null);
		pantalla.setResizable(false);
		pantalla.setVisible(true);
	}
}
